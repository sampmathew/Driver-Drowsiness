Driver-Drowsiness-Detection  

This is a Python project that detects drowsiness in users and rings an alarm.  
Project Authors: Varkey P Mathew, Esakki Rajan, Pawankumar N, Sri Hari S.  

Project Overview :
Driver drowsiness detection is built using Dlib and OpenCV, with Python as the backend language.  

Logic of the Project : 
The project leverages the **68 facial landmark detector** and the face detector from the Dlib library.  
- The 68 facial landmark detector is a robustly trained model that detects points on the human face.  
- These points are used to determine whether the eyes are open or closed.  

 Working of the Project  
1. **Landmark Detection**:  
   - The detector identifies facial landmarks, as shown in the image below.  

2. **Eye Aspect Ratio (EAR)**:  
   - The ratio is calculated as:  
     *Sum of distances of vertical landmarks divided by twice the distance between horizontal landmarks*.  
   - This ratio helps determine thresholds for different states:  
     - Sleeping  
     - Drowsy  
     - Active  

Screenshots  
- Active  
- Drowsy  
- Sleepy  

Resources  
- **68-landmark detector data (.dat) file**: [Download here](http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2)  
